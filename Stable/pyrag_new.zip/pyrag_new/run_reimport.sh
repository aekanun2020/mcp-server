#!/bin/bash
# Script to run the reimport Python script

cd /Users/grizzlym1/Desktop/test/pyrag_new
python3 reimport_tool_use.py
