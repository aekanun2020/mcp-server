"""RAGDocs - Fast MCP for Documentation Retrieval."""

__version__ = "0.1.0"
