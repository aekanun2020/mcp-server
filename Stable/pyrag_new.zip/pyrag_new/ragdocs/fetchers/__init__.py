"""Web content fetchers for RAGDocs."""

from .web import WebFetcher

__all__ = [
    'WebFetcher',
]
