"""Utility functions and classes for PyRAGDoc."""
