"""Example implementations of PyRAGDoc."""
